<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="Styles/styles_AP.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  
</head>

<body>
 <div class="header">
    <img src="Images/logo.png" alt="Logo" /> 
    <h1>Where We Started</h1> </div>

<div class="navbar">
  <a class="nav-item" href="HMP2.php"> <i class="fa-solid fa-house"></i> Home</a>
  <a class="nav-item" href="AP.php"> <i class="fa-solid fa-book"></i> About Us</a>
  <div class="dropdown nav-item">
    <a class="nav-item" href="#"> <i class="fa-solid fa-check"></i> Reservations</a>
    <div class="dropdown-content">
      <a class="dropdown-item" href="reservation.php">Make a Reservation</a>
      <a class="dropdown-item" href="attractions.php">Explore</a>
      <a class="dropdown-item" href="lookup.php">Reservation Confirmation</a>
      <a class="dropdown-item" href="reservationsummary.php">Reservation Summary</a>
    </div>
  </div>

        <?php
            include 'user_status.php';
        ?>
</div>
    
    <div class="container">
    <img src="Images/AP_IMG.jpeg" alt="MBL_Night" class="image">
    
    <p><b>Moffat Bay Lodge: A Legacy of Wilderness</b></p>

    <p>Nestled amidst the rugged beauty of the Canadian wilderness, Moffat Bay Lodge stands as a testament to the allure of nature's splendor and the spirit of hospitality. Established in 1953, Moffat Bay Lodge has carved its place in Ontario's rich history, offering nature enthusiasts a sanctuary of tranquility and adventure.</p>

    <p>The origins of Moffat Bay Lodge trace back to the pioneering vision of Todd Daniels, who was captivated by the untamed majesty of what Moffat Bay had to offer. What began as a humble outpost for fishing and hunting expeditions evolved into a restful retreat, cherished by generations of visitors seeking respite from the bustle of modern life.
    Over the decades, Moffat Bay Lodge has witnessed the ebb and flow of time, adapting to changing tastes and technologies while remaining steadfast in its commitment to preserving the pristine wilderness that surrounds it.
    </p>

    <p>Today, Moffat Bay Lodge stands as more than just a destination; it is a living legacy, a place where memories are made, and bonds are forged amidst the timeless beauty of nature. Whether casting a line into the crystal-clear waters, exploring the winding trails that crisscross the forest, or simply basking in the serenity of the sunset over the tranquil bay, visitors to Moffat Bay Lodge find themselves immersed in a world of unparalleled natural splendor.</p>

    <p>As Moffat Bay Lodge continues to write its story, it remains a beacon of hospitality, welcoming travelers from near and far to experience the magic of Ontario's wilderness. With each passing year, its legacy grows, a testament to the enduring power of nature to inspire, rejuvenate, and connect us all.</p>

    </div>
    
   <div class="container2">
  <img src="Images/Fam.jpeg" alt="MBL_Fam" class="image2">
  <img src="Images/Fam2.jpeg" alt="MBL_Fam2" class="image2">
    </div>


  <div class="footer">
  <footer>
    &copy; 2024 Moffat Bay Lodge. All rights reserved.<br> 
    <br>
    <i class="fas fa-envelope"></i> 
    Contact Us: <a href="mailto:info@moffatbaylodge.com">info@moffatbaylodge.com</a> 
  </footer>
</div>
</body>

</html>
