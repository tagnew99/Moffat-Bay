<?php

session_start();

$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the homepage
header("Location: HMP2.php");
exit;
?><?php

session_start();

$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the homepage
header("Location: HMP2.php");
exit;
?><?php

session_start();

$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the homepage
header("Location: HMP2.php");
exit;
?>